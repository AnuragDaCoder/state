﻿

using StatePattern;

BankAccount bankAccount = new();
bankAccount.DepositAmount(200);
bankAccount.WithdrawAmount(700);
bankAccount.WithdrawAmount(100);

