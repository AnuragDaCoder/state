﻿
namespace StatePattern
{
    public abstract class BankAccountState
    {
        public BankAccount BankAccount { get; protected set; } = null!;
        public decimal Balance { get; protected set; }
        public abstract void Deposit(decimal amount);
        public abstract void Withdraw(decimal amount);
    }

    public class NormalState : BankAccountState
    {
        public NormalState(decimal balance, BankAccount bankAccount)
        {
            Balance = balance;
            BankAccount = bankAccount;
        }

        public override void Deposit(decimal amount)
        {
            Console.WriteLine($"In {GetType()} , depositing {amount}");
            Balance += amount;
        }

        public override void Withdraw(decimal amount)
        {
            Console.WriteLine($"In {GetType()} , withdrawing {amount} from {Balance}");
            Balance -= amount;
            if (Balance < 0)
            {
                BankAccount.BankAccountState = new NegativeBalanceState(Balance, BankAccount);
            }
        }
    }

    public class NegativeBalanceState : BankAccountState
    {
        public NegativeBalanceState(decimal balance, BankAccount bankAccount)
        {
            Balance = balance;
            BankAccount = bankAccount;
        }

        public override void Deposit(decimal amount)
        {
            Console.WriteLine($"In {GetType()}, depositing {amount}");
            Balance += amount;
            if (Balance >= 0)
            {
                BankAccount.BankAccountState = new NormalState(Balance, BankAccount);
            }
        }

        public override void Withdraw(decimal amount)
        {
            Console.WriteLine($"In {GetType()}, cannot withdraw, balance {Balance}");
        }
    }
    public class BankAccount
    {
        public BankAccountState BankAccountState { get; set; }

        public BankAccount()
        {
            BankAccountState = new NormalState(200, this);
        }

        public void DepositAmount(decimal amount)
        {
            BankAccountState.Deposit(amount);
        }

        public void WithdrawAmount(decimal amount)
        {
            BankAccountState.Withdraw(amount);
        }
    }
}
